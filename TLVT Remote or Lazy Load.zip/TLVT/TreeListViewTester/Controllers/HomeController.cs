﻿using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;
using TreeListViewTester.Models;

namespace TreeListViewTester.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult LoadBaseView()
        {
            return View();
        }

        public JsonResult GetDataForTS([DataSourceRequest] DataSourceRequest request, int ? number)
        {
            var data = new List<StudentHeirarchy>
                {
                    new StudentHeirarchy {ID = 0, Name = "Headmaster Jenkins", ReportsTo = null  },
                };

            for(var count = 0; count < 50; count ++)
            {
                var model = new StudentHeirarchy
                {
                    ID = count,
                    Name = "Dude" + (count + 9),
                };

                if(count > 3)
                {
                    if(count % 2 == 1)
                    {
                        //model.ReportsTo = 20 / 2
                    }
                    if (count % 3 == 1)
                    {
                        model.ReportsTo = 50 / count + 3;
                    }

                    if(count % 6 == 1)
                    {
                        model.ReportsTo = 120 / count + 6;
                    }
                }
                

                data.Add(model);
            }

            int? tt = 21;

            return Json(data.ToTreeDataSourceResult(request,
            e => e.ID,
            e => e.ReportsTo,
            //e => tt.HasValue ? e.ReportsTo == tt : e.ReportsTo == 0,
            e => e));
        }

        
    }
}
