﻿namespace TreeListViewTester.Models
{
    public class StudentHeirarchy
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int? ReportsTo { get; set; }
    }
}
